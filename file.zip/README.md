<p align="center">
<a href="https://telegra.ph/file/3fc1e4f4ea4e38b83f654.jpg"><img src="https://telegra.ph/file/3fc1e4f4ea4e38b83f654.jpg"</a>
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Orbitron&size=28&duration=3000&pause=1000&color=964B00&width=456&lines=KIKUCHANJ+WABOT+MD;CREATED+BY+TAKASHI+KEMII" alt="Typing SVG" /></a>
<img src="https://img.shields.io/badge/rating-★★★★★-brightgreen"/>
<img src="https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges"/>
<a href="https://github.com/Takashi-Kemii/Kiku"><img src="https://img.shields.io/github/watchers/Takashi-Kemii/Kiku.svg"</a>
<a href="https://github.com/Takashi-Kemii/Kiku"><img src="https://img.shields.io/github/stars/Takashi-Kemii/Kiku.svg"</a>
<a href="https://github.com/Takashi-Kemii/Kiku"><img src="https://img.shields.io/github/forks/Takashi-Kemii/Kiku.svg"</a>
<a href="https://github.com/Takashi-Kemii/Kiku"><img src="https://img.shields.io/github/repo-size/Takashi-Kemii/Kiku.svg"></a>
<img src="https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png"/>

Bot chat WhatsApp adalah program kecerdasan buatan AI (artificial intelligence) yang dimiliki oleh WhatsApp Business API. Sistem bot ini mampu berperan sebagai asisten virtual yang membalas setiap pesan WhatsApp secara otomatis dalam hitungan detik.

<details close="close">
<summary>Bot Ini Dikembangkan Oleh <b>Takashi Kemii</b></summary>
<a href="http://wa.me/628816609112"><img src="https://img.shields.io/badge/Whatsapp-30302f?style=flat&logo=whatsapp"></a>
<a href="http://www.instagram.com/thiskemii"><img src="https://img.shields.io/badge/Instagram-30302f?style=flat&logo=instagram"></a>
</details><details close="close"><summary>Tutorial Menginstall <b>Kiku - Wabot</b></summary>

- `Select The Language`

`you can choose Indonesian or English`
<details close="close">
<summary><i><b>Indonesian</b></i></summary>

***
### 1. Install Aplikasi [Termux](https://f-droid.org/repo/com.termux_118.apk)
> Setelah Install Aplikasi Termux, Silahkan Salin Teks Dibawah, Setelah Disalin Tempel Di Aplikasi Termux.
```
pkg update -y;pkg upgrade -y;pkg install nodejs -y;pkg install git -y;git clone https://github.com/Takashi-Kemii/Kiku.git && cd Kiku;rm -rf session.json;node index
```
### 2. Pairing Code
> Setelah Menempel Nomer Kalian Ke Termux/Panel, Nanti Akan Muncul Code Pairingnya, Kalian Bisa Masukan Code Tersebut Di Whatsapp Kalian.
### 3. Catatan
> Saya Sarankan Jangan Menggunakan Whatsapp/Nomor Pribadi
***
</details><details close="close"><summary><i><b>English</b></i></summary>

***
### 1. Install The [Termux](https://f-droid.org/repo/com.termux_118.apk) App
> After Installing The Termux Application, Please Copy The Text Below, After Copying Paste In The Termux Application.
```
pkg update -y;pkg upgrade -y;pkg install nodejs -y;pkg install git -y;git clone https://github.com/Takashi-Kemii/Kiku.git && cd Kiku;rm -rf session.json;node index
```
### 2. Pairing Code
> After pasting your number into Termux/Panel, the pairing code will appear, you can enter the code in your WhatsApp.
### 3. Note
> I Suggest Don't Use Whatsapp/Personal Number
***
</details></details>
<img src="https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png"/>

### Features
- [x] Bug
- [x] Buggc
- [x] Jadibot
- [x] Trade
- [x] Sosmed
- [x] GroupSetting
- [x] Kick & Add
- [x] Promote & Demote
- [x] Chat & Call
- [x] Public & Private
- [x] Restart & Shutdown
- [ ] And others

### Changelogs
<details open="open"><summary>Added <b>New Features</b></summary>

```
.sosmed (fake sosmed)
.jadibot (numpang bot)
.ai (openai module)
.dalle3 (create image)
.bug (bug number)
.buggc (bug group)
.fix (fixed all error)
.trade (ongoing)
```
</details>
