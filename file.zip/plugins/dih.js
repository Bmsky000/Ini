let handler = async (m) => {
    m.reply(`dih`)
}
handler.customPrefix = /^(i love you)$/i;
handler.command = new RegExp();

handler.limit = true

module.exports = handler