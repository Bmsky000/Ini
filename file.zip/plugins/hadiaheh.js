let handler = async (m, { conn }) => {
setInterval(() => {
	conn.sendFile("120363030765067775@g.us", `https://telegra.ph/file/11b41175141f614392de4.jpg`, pickRandom(teks), null)
	}, 60 * 1000 * 8)
}
handler.help = ['heit']
handler.tags = ['main']

handler.command = /^(mp)$/i
handler.premium = true
handler.register = true
handler.limit = 1
module.exports = handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
  }
  
  const teks = [
  "salah satu player telah menuju dungeon💀",
  "salah satu player terbanned dari server",
  "salah satu player mati karna kebodohan",
  "salah satu player mendapatkan cincin owner",
  "salah satu player premium gratis",
  "salah satu player mendapatkan 100🎉🔥 tiket",
  "salah satu player mendapatkan 76 tiket",
  "salah satu player mendapatkan 78 tiket",
  "salah satu player mendapatkan 56 tiket",
  "salah satu player mendapatkan 20 tiket",
  "salah satu player mendapatkan 87 tiket",
  "salah satu player mendapatkan 23 tiket",
  "salah satu player mendapatkan 1 tiket",
  "salah satu player mendapatkan *zonk️💀* tiket",
  "salah satu player mendapatkan 18 tiket",
  "salah satu player mendapatkan 98 tiket",
  "salah satu player mendapatkan 99 tiket",
  "salah satu player mendapatkan 100🔥🎉 tiket"
  ]