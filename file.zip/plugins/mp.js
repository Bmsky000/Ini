let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, `https://telegra.ph/file/449cea73d3b4e865e399b.jpg`, 'tutor.jpg', 'jika kalian sudah mendownload lagu dari botnya, kalian download filenya terus kalian tekaan filenya, kemudian kalian klik titik 3 pojok kanan atas, teruss klik share atau bagikan, kemudian pilih aplikasi penyimpan kalian, selesai. oh iya biar lebih enak buat nyari filenya, kalian pindahin aja file musiknya ke folder musik kalian.', m)
}
handler.help = ['mp']
handler.tags = ['main']

handler.command = /^(mp)$/i
handler.premium = false
handler.register = true
handler.limit = 1
module.exports = handler