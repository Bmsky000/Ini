let handler = async (m) => {
    m.reply(`nama saya alesya kak`)
}
handler.customPrefix = /^(nama kamu syapa)$/i;
handler.command = new RegExp();

handler.limit = true

module.exports = handler